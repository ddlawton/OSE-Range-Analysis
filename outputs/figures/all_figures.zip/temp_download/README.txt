OSE Range Analysis - Complete Figure and Table Package
====================================================

Generated on: Thu Sep 10 19:22:00 UTC 2026
Website: https://ddlawton.github.io/OSE-Range-Analysis
Repository: https://github.com/ddlawton/OSE-Range-Analysis

This package contains ALL figures and tables from the complete analysis,
matching exactly what appears on the published website.

CONTENTS:

FIGURES/ (organized by website page; each figure includes PNG, SVG, and PDF)
  ├── manuscript_methods_results/     Main manuscript figures and visualizations
  ├── basic_stats/                    Study area maps and dataset summaries
  ├── locust_damage_treatment_region/ Damage analysis by treatment and region
  ├── locust_density_treatment_region/ Density analysis by treatment and region
  ├── locust_density_ground_cover/    Vegetation-locust relationships
  ├── locust_density_temperature/     Temperature-locust dynamics
  ├── yield_locust/                   Locust impact on yield
    ├── yield_treatment_region/         Regional fertilizer effects on yield
    ├── yield_environment/              Yield-temperature exploratory figures
    └── farmer_gender_analysis/         Farmer gender dynamics figures

TABLES/ (CSV + raster + vector formats)
  ├── manuscript_methods_results/     Main manuscript statistical tables
  │   ├── csv/                        Raw data tables for reanalysis
    │   ├── png/                        Publication-ready raster table images
    │   ├── pdf/                        Vector-ready table exports
    │   └── html/                       Editable table exports
  ├── basic_stats/                    Dataset summaries and rainfall data
    │   ├── csv/
    │   ├── png/
    │   ├── pdf/
    │   └── html/
  ├── locust_damage_treatment_region/ Damage model summaries and comparisons
    │   ├── csv/
    │   ├── png/
    │   ├── pdf/
    │   └── html/
  ├── locust_density_treatment_region/ Density model summaries and comparisons
    │   ├── csv/
    │   ├── png/
    │   ├── pdf/
    │   └── html/
  ├── locust_density_ground_cover/    Ground cover mediation analysis
    │   ├── csv/
    │   ├── png/
    │   ├── pdf/
    │   └── html/
  ├── yield_locust/                   Yield-locust relationship models
    │   ├── csv/
    │   ├── png/
    │   ├── pdf/
    │   └── html/
  └── yield_treatment_region/         Yield analysis by treatment and region
            ├── csv/
            ├── png/
            ├── pdf/
            └── html/

TABLE FORMATS:
    - CSV files: Raw data tables for reanalysis and data reuse
    - PDF files: Vector-ready tables for Adobe/illustration workflows
    - HTML files: Editable table exports with preserved styling
    - PNG files: Publication-ready table images (300 DPI, max 10" wide)

FIGURE DETAILS:
- Vector figure exports are provided when available (PDF/SVG/EPS)
- SVG figures are auto-converted to PDF when rsvg-convert is available
- Every PNG figure includes an SVG companion (embedded-image fallback if needed)
- Every figure includes a PDF companion (vector-first, PNG fallback)
- PNG figure fallbacks match website display dimensions and quality
- Total raster figures: 0
- Total vector figures: 0
- Total table files: 84
- Total vector tables (PDF): 21

REPRODUCIBILITY:
All outputs generated from code at:
https://github.com/ddlawton/OSE-Range-Analysis

To regenerate all outputs:
1. Clone the repository
2. Install R and required packages (see README.md)
3. Run: quarto render

CITATION:
Lawton, D. et al. (submitted) Journal of Economic Entomology
Zenodo DOI: https://doi.org/10.5281/zenodo.xxxxxx

For questions or issues, please open an issue on GitHub:
https://github.com/ddlawton/OSE-Range-Analysis/issues

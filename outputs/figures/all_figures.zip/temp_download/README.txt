OSE Range Analysis - Complete Figure and Table Package
====================================================

Generated on: Sun Nov 23 18:22:45 UTC 2025
Website: https://ddlawton.github.io/OSE-Range-Analysis
Repository: https://github.com/ddlawton/OSE-Range-Analysis

This package contains ALL figures and tables from the complete analysis,
matching exactly what appears on the published website.

CONTENTS:

FIGURES/ (organized by analysis section)
  ├── basic_stats/                    Study area maps and dataset summaries
  ├── locust_density_treatment_region/   Treatment effects across regions
  ├── locust_density_ground_cover/       Vegetation-locust relationships
  ├── locust_density_temperature/        Temperature-locust dynamics
  ├── yield_environment/             Environmental yield factors
  ├── yield_locust/                  Locust impact on yield
  └── yield_treatment_region/        Regional fertilizer effects

TABLES/ (CSV format for analysis reuse)
  └── [same structure as figures]/    Model summaries, statistics, comparisons

FIGURE DETAILS:
- All figures match website display dimensions and quality
- PNG format at publication resolution
- Meaningful filenames based on analysis content
- Total figures: 12
- Total tables: 13

REPRODUCIBILITY:
All outputs generated from code at:
https://github.com/ddlawton/OSE-Range-Analysis

CITATION:
Lawton, D. et al. (submitted) Journal of Economic Entomology
Zenodo DOI: https://doi.org/10.5281/zenodo.xxxxxx
